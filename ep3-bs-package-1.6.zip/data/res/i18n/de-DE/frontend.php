<?php

return array(

    'Today' => 'Heute',
    'Date' => 'Datum',
    'Time' => 'Zeit',
    'Show' => 'Anzeigen',

    'To book %s, %splease register first%s' => 'Um %s zu buchen, %sregistrieren Sie sich bitte%s',
    'or simply %s login here' => 'oder melden %s Sie sich an',

    'Email address' => 'E-Mail Adresse',
    'Email' => 'E-Mail',
    'Phone' => 'Tel.',
    'Password' => 'Passwort',
    'Login' => 'Anmelden',
    'Logout' => 'Abmelden',

    'New password' => 'Neues Passwort',

    'Get additional %shelp and information%s' => 'Hier erhalten Sie zusätzliche %sHilfe und Infos%s',

    'Online as %s' => 'Angemeldet als %s',

    'Administration' => 'Verwaltung',

    'My bookings' => 'Meine Buchungen',
    'My account' => 'Meine Daten',

);
