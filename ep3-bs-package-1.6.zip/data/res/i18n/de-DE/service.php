<?php

return array(

    'System status' => 'Status des Systems',
    'Maintenance' => 'Wartungsarbeiten',

    'Help' => 'Hilfe',

    'We are currently working on this page.' => 'Diese Seite ist leider noch nicht fertig.',

    'The system is currently not available' => 'Das System ist derzeit nicht verfügbar',
    'System maintenance underway' => 'Es finden gerade Wartungsarbeiten statt',
    'We are back as fast as we can. Promised!' => 'Wir sind so schnell wie möglich wieder für Sie da!',

    'The system is available' => 'Das System ist verfügbar',

);