<?php

namespace Base\Table;

use Zend\Db\TableGateway\TableGateway;

class OptionTable extends TableGateway
{

    const NAME = 'bs_options';

}