<?php

namespace Booking\Table\Booking;

use Zend\Db\TableGateway\TableGateway;

class BillTable extends TableGateway
{

    const NAME = 'bs_bookings_bills';

}