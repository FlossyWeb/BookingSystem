<?php

namespace Booking\Table;

use Zend\Db\TableGateway\TableGateway;

class BookingMetaTable extends TableGateway
{

    const NAME = 'bs_bookings_meta';

}