<?php

namespace Event\Table;

use Zend\Db\TableGateway\TableGateway;

class EventTable extends TableGateway
{

    const NAME = 'bs_events';

}