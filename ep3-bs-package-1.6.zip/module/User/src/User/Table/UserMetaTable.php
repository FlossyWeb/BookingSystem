<?php

namespace User\Table;

use Zend\Db\TableGateway\TableGateway;

class UserMetaTable extends TableGateway
{

    const NAME = 'bs_users_meta';

}